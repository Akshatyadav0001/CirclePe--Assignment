import './Group1116599854.css'

export default function Group1116599854() {
  return (
    <div className="group-1116599854">
      <div className="component-11">
        <img className="ellipse-92" src="assets/vectors/Ellipse9212_x2.svg" />
        <div className="rectangle-9">
        </div>
        <div className="container">
          <img className="group-1" src="assets/vectors/Group111_x2.svg" />
          <div className="frame-23">
            <p className="step-3">
            <span className="step-3-sub-240"></span><span></span>
            </p>
            <div className="line-23">
            </div>
            <span className="smooth-onboarding-for-the-tenant-begins">
            Smooth Onboarding for the Tenant begins
            </span>
          </div>
          <div className="screenshot-20240213-at-2171">
          </div>
        </div>
      </div>
      <div className="rectangle-5064">
      </div>
    </div>
  )
}