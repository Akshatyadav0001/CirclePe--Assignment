import './Group1116599856.css'

export default function Group1116599856() {
  return (
    <div className="group-1116599856">
      <div className="component-11">
        <img className="ellipse-92" src="assets/vectors/Ellipse9211_x2.svg" />
        <div className="rectangle-9">
        </div>
        <div className="screenshot-20240213-at-2171">
        </div>
        <div className="container">
          <img className="group-1" src="assets/vectors/Group17_x2.svg" />
          <div className="frame-23">
            <p className="step-1">
            <span className="step-1-sub-240"></span><span className="step-1-sub-239"></span><span></span>
            </p>
            <div className="line-23">
            </div>
            <span className="we-make-it-possible-in-aquick-and-easy-few-steps-process-takes-max-5-mins">
            Tenant selects the property
            </span>
          </div>
          <span className="tenant-selectsflexiblerent-tenure-corresponding-amount">
          Tenant selects flexible rent tenure &amp; corresponding amount
          </span>
        </div>
      </div>
      <div className="rectangle-5064">
      </div>
    </div>
  )
}