import './MacBookPro1413.css'

export default function MacBookPro1413() {
  return (
    <div className="mac-book-pro-1413">
      <img className="ellipse-92" src="assets/vectors/Ellipse929_x2.svg" />
      <div className="container-2">
        <div className="container-1">
          <div className="frame-46">
            <p className="step-3">
            <span className="step-3-sub-235"></span><span className="step-3-sub-0"></span><span></span>
            </p>
          </div>
          <div className="line-23">
          </div>
          <div className="frame-43">
            <div className="ellipse-94">
            </div>
            <span className="smooth-onboarding-for-the-tenant-begins">
            Smooth Onboarding for the Tenant begins
            </span>
          </div>
        </div>
        <div className="container">
          <div className="rectangle-9">
          </div>
          <img className="group-1" src="assets/vectors/Group12_x2.svg" />
        </div>
      </div>
      <div className="screenshot-20240213-at-2171">
      </div>
      <div className="container">
      </div>
    </div>
  )
}