import './Group1116599853.css'

export default function Group1116599853() {
  return (
    <div className="group-1116599853">
      <div className="component-11">
        <img className="ellipse-92" src="assets/vectors/Ellipse922_x2.svg" />
        <div className="rectangle-9">
        </div>
        <div className="container">
          <img className="group-1" src="assets/vectors/Group112_x2.svg" />
          <div className="frame-23">
            <p className="step-2">
            <span className="step-2-sub-240"></span><span className="step-2-sub-239"></span><span></span>
            </p>
            <div className="line-23">
            </div>
            <span className="tenant-selects-pay-with-circle-enabling">
            Tenant selects Pay with Circle enabling :
            </span>
          </div>
          <div className="zero-security-deposit-move-in-reduced-rent-offer-3-months-salary-cover">
          Zero security deposit move-in<br />
          Reduced rent offer<br />
          3 months salary cover
          </div>
          <div className="screenshot-20240213-at-2171">
          </div>
        </div>
      </div>
      <div className="rectangle-5064">
      </div>
    </div>
  )
}