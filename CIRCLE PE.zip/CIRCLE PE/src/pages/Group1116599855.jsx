import './Group1116599855.css'

export default function Group1116599855() {
  return (
    <div className="group-1116599855">
      <div className="component-11">
        <img className="ellipse-92" src="assets/vectors/Ellipse927_x2.svg" />
        <div className="rectangle-9">
        </div>
        <div className="container">
          <img className="group-1" src="assets/vectors/Group14_x2.svg" />
          <div className="frame-23">
            <p className="step-4">
            <span className="step-4-sub-240"></span><span></span>
            </p>
            <div className="line-23">
            </div>
            <span className="tenant-gets-approved-to-move-in">
            Tenant gets approved to move-in
            </span>
          </div>
          <div className="gets-zero-security-deposit-approval-zero-cost-emi-monthly-rent">
          Gets Zero-security deposit approval<br />
          Zero cost EMI = Monthly Rent
          </div>
          <div className="screenshot-20240213-at-2171">
          </div>
        </div>
      </div>
      <div className="rectangle-5064">
      </div>
    </div>
  )
}